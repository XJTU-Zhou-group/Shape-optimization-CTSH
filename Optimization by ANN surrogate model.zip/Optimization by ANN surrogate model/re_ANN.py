import os
os.environ['TF_ENABLE_AUTO_MIXED_PRECISION'] = '1'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import numpy as np
import tensorflow as tf

file_save = 'E:/2022_4_AIAAJ/ANN Surrogate model2/model2/model_ANN.ckpt'
n1 = 64
n2 = 64

x1 = 54.897
x2 = 70.881
x3 = 61.943
x4 = 6.6596
x5 = 5.0


x1 = float(x1)
x2 = float(x2)
x3 = float(x3)
x4 = float(x4)
x5 = float(x5)

mean_list = np.genfromtxt('E:/2022_4_AIAAJ/ANN Surrogate model2/model2/mean_list.csv', dtype=float, delimiter=',')
std_list = np.genfromtxt('E:/2022_4_AIAAJ/ANN Surrogate model2/model2/std_list.csv', dtype=float, delimiter=',')

x12345 = (np.array([[x1, x2, x3, x4, x5]])-mean_list[0:5])/std_list[0:5]

input1 = tf.compat.v1.placeholder(tf.float32)
output = tf.compat.v1.placeholder(tf.float32)

n_input = 5
n_output = 6

def weight_variable(shape):
    initial = tf.random.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

keep_prob = tf.compat.v1.placeholder(tf.float32)

W_fc1 = weight_variable([n_input, n1])
b_fc1 = bias_variable([n1])

h_fc1 = tf.nn.relu(tf.matmul(input1, W_fc1) + b_fc1)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([n1, n2])
b_fc2 = bias_variable([n2])

h_fc2 = tf.nn.relu(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)
h_fc2_drop = tf.nn.dropout(h_fc2, keep_prob)

W_fc3 = weight_variable([n2, n_output])
b_fc3 = bias_variable([n_output])
output_predict = tf.matmul(h_fc2_drop, W_fc3) + b_fc3

saver = tf.compat.v1.train.Saver()

tf_config = tf.compat.v1.ConfigProto()
tf_config.gpu_options.allow_growth = True

with tf.compat.v1.Session(config=tf_config) as sess:
    saver.restore(sess, file_save)
    y123456 = sess.run(output_predict, feed_dict={input1: x12345, keep_prob: 1.0}) * std_list[5:] + mean_list[5:]
    sess.close()
#123456
y1 = y123456[0, 0]
y2 = y123456[0, 1]
y3 = y123456[0, 2]
y4 = y123456[0, 3]
y5 = y123456[0, 4]
y6 = y123456[0, 5]
np.savetxt('Energy.txt', np.array([y1]))
np.savetxt('FI1-nodes.txt', np.array([y2]))
np.savetxt('FI2-nodes.txt', np.array([y3]))
np.savetxt('FI3-nodes.txt', np.array([y4]))
np.savetxt('mass.txt', np.array([y5]))
np.savetxt('Moment.txt', np.array([y6]))