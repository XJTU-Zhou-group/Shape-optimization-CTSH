data = importdata('data.xlsx');
dlmwrite('data.csv',data,'precision',10);
%%
data = importdata('data.csv');
tr = importdata('output_train.csv');
for i = 1:1:4
    figure();
    scatter(tr(:,i),data(1:240,i+5));
end
te = importdata('output_text.csv');
for i = 1:1:4
    figure();
    scatter(te(:,i),data(241:250,i+5));
end