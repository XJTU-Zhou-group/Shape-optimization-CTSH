import numpy as np
import tensorflow as tf
import random
import os
os.environ['TF_ENABLE_AUTO_MIXED_PRECISION'] = '1'
n_train = 240
batch_size = 32
train_step = 100000
step_display = 1000
learning_reat_base = 0.01
learning_reat_step = 100
learning_reat_decay = 0.99
n1 = 64
n2 = 64
kp = 1.0
l2_reat = 0.0004
file_data = 'data.csv'
file_output_tr = 'output_train.csv'
file_output_te = 'output_text.csv'
file_save = 'model_ANN.ckpt'
data = np.genfromtxt(file_data, dtype=float, delimiter=',')

mean_list = np.mean(data[0:n_train], axis=0)
std_list = np.std(data[0:n_train], axis=0)
data = (data-mean_list)/std_list
row, col = data.shape

print('row = ' + str(row) + ', col = ' + str(col))
print(data)

n_text = row-n_train

input_train = data[0: n_train, 0: 5]
input_text = data[n_train: row, 0: 5]
output_train = data[0: n_train, 5: 9]
output_text = data[n_train: row, 5: 9]

input1 = tf.placeholder(tf.float32)
output = tf.placeholder(tf.float32)

n_input = int(input_train.shape[1])
n_output = int(output_train.shape[1])

print('n_input = ' + str(n_input))
print('n_output = ' + str(n_output))

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

keep_prob = tf.placeholder(tf.float32)

W_fc1 = weight_variable([n_input, n1])
b_fc1 = bias_variable([n1])

h_fc1 = tf.nn.relu(tf.matmul(input1, W_fc1) + b_fc1)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([n1, n2])
b_fc2 = bias_variable([n2])

h_fc2 = tf.nn.relu(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)
h_fc2_drop = tf.nn.dropout(h_fc2, keep_prob)

W_fc3 = weight_variable([n2, n_output])
b_fc3 = bias_variable([n_output])
output_predict = tf.matmul(h_fc2_drop, W_fc3) + b_fc3

loss = tf.reduce_mean(tf.abs(output_predict - output))
loss_l2 = tf.contrib.layers.l2_regularizer(l2_reat)(W_fc1) + tf.contrib.layers.l2_regularizer(l2_reat)(W_fc2)\
          + tf.contrib.layers.l2_regularizer(l2_reat)(W_fc3)

global_steps = tf.Variable(0, trainable=False)
learning_rate = tf.train.exponential_decay(learning_reat_base, global_steps, learning_reat_step, learning_reat_decay,
                                           staircase=True)
train_op = tf.train.AdamOptimizer(learning_rate).minimize(loss+loss_l2, global_step=global_steps)
saver = tf.train.Saver()

tf_config = tf.ConfigProto()
tf_config.gpu_options.allow_growth = True

with tf.Session(config=tf_config) as sess:
    init_op = tf.global_variables_initializer()
    sess.run(init_op)

    for step in range(train_step):
        index = random.sample(range(0, n_train), batch_size)
        sess.run(train_op, feed_dict={input1: input_train[index], output: output_train[index], keep_prob: kp})
        if step % step_display == 0:
            loss_tr = sess.run(loss, feed_dict={input1: input_train, output: output_train, keep_prob: 1.0})
            loss_te = sess.run(loss, feed_dict={input1: input_text, output: output_text, keep_prob: 1.0})
            print('step: ' + str(step))
            print('loss_tr: ' + str(loss_tr) + '  loss_te: ' + str(loss_te) + '  loss_l2: ' + str(sess.run(loss_l2)))
    loss_tr = sess.run(loss, feed_dict={input1: input_train, output: output_train, keep_prob: 1.0})
    loss_te = sess.run(loss, feed_dict={input1: input_text, output: output_text, keep_prob: 1.0})
    print('step: ' + str(step))
    print('loss_tr: ' + str(loss_tr) + '  loss_te: ' + str(loss_te))
    output_train_2 = sess.run(output_predict, feed_dict={input1: input_train, keep_prob: 1.0})
    output_train_2 = output_train_2 * std_list[5: 9] + mean_list[5: 9]
    output_text_2 = sess.run(output_predict, feed_dict={input1: input_text, keep_prob: 1.0})
    output_text_2 = output_text_2 * std_list[5: 9] + mean_list[5: 9]
    np.savetxt(file_output_tr, output_train_2)
    np.savetxt(file_output_te, output_text_2)
    np.savetxt('mean_list.csv', mean_list)
    np.savetxt('std_list.csv', std_list)
    saver.save(sess, file_save)