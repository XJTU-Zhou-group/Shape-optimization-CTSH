#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
from textRepr import prettyPrint
import numpy
from numpy import linalg
import time
from os.path import exists


#point  4mm<y0<15mm������slot���ȣ���x0�̶�
x0=0
y0=5

#point0 y1=y0, x1�̶�������slot���ȣ�
x1=45
y1=y0

#point1 y1=y0, x1�̶�������slot���ȣ�
#x7=45
#y7=-y0

#point2     45mm<x2<60mm       0mm<y2<15mm
x2=58.193
y2=9.195

#point3     60mm<x3<75mm       0mm<y3<15mm
x3=73.881
y3=8.1728

#point4     60mm<x4<75mm       y4=0�̶�
x4=61.128
y4=0

#point5     60mm<x5<75mm       -15mm<y5<0mm
#x5=60
#y5=-11.49


#��������tube-hingeʵ��
mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
mdb.models['Model-1'].sketches['__profile__'].CircleByCenterPerimeter(center=(
    0.0, 0.0), point1=(19.0, 0.0))
mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-1', type=
    DEFORMABLE_BODY)
mdb.models['Model-1'].parts['Part-1'].BaseShellExtrude(depth=220, sketch=
    mdb.models['Model-1'].sketches['__profile__'])
del mdb.models['Model-1'].sketches['__profile__']

#�����ο�ƽ�棬�����и�tube-hinge
mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=0.0, principalPlane=XYPLANE)
mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=0.0, principalPlane=YZPLANE)
mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=0.0, principalPlane=XZPLANE)
mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=19.0, principalPlane=YZPLANE)

#ƽ��y-z�ο�ƽ�棬������ͼ�����������и�slot
mdb.models['Model-1'].parts['Part-1'].DatumCsysByThreePoints(coordSysType=
    CARTESIAN, line1=(1.0, 0.0, 0.0), line2=(0.0, 1.0, 0.0), name=
    'Datum csys-1', origin=(0.0, 0.0, 0.0))

mdb.models['Model-1'].ConstrainedSketch(gridSpacing=22.19, name='__profile__', 
    sheetSize=887.9, transform=
    mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
    sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[5], 
    sketchPlaneSide=SIDE1, 
    sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[6].axis2, 
    sketchOrientation=RIGHT, origin=(19.0, 0.0, 110.0)))

mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
    0.0), point2=(1.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mdb.models['Model-1'].sketches['__profile__'].geometry[2])
mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
    0.0), point2=(0.0, 1.0))
mdb.models['Model-1'].sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=mdb.models['Model-1'].sketches['__profile__'].geometry[3])

mdb.models['Model-1'].sketches['__profile__'].Line(point1=(x0, y0), point2=(45-12, y1))#g4
mdb.models['Model-1'].sketches['__profile__'].Spline(points=((45-12, y1), (x2-12, y2), (x3-12, y3), (x4-12, y4),(x3-12,-y3),(x2-12,-y2),(45-12,-y1)))#g5
mdb.models['Model-1'].sketches['__profile__'].Line(point1=(x0, -y0), point2=(45-12, -y1))#g6

mdb.models['Model-1'].sketches['__profile__'].copyMirror(mirrorLine=
    mdb.models['Model-1'].sketches['__profile__'].geometry[3], objectList=(
    mdb.models['Model-1'].sketches['__profile__'].geometry[4], 
    mdb.models['Model-1'].sketches['__profile__'].geometry[5],
    mdb.models['Model-1'].sketches['__profile__'].geometry[6]))
mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
    sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
    RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[5], 
    sketchPlaneSide=SIDE1, sketchUpEdge=
    mdb.models['Model-1'].parts['Part-1'].datums[6].axis2)
del mdb.models['Model-1'].sketches['__profile__']


#��ʵ���и�����ɲ���
mdb.models['Model-1'].parts['Part-1'].PartitionFaceByDatumPlane(datumPlane=
    mdb.models['Model-1'].parts['Part-1'].datums[3], faces=
    mdb.models['Model-1'].parts['Part-1'].faces.getSequenceFromMask(('[#1 ]', 
    ), ))
mdb.models['Model-1'].parts['Part-1'].PartitionFaceByDatumPlane(datumPlane=
    mdb.models['Model-1'].parts['Part-1'].datums[4], faces=
    mdb.models['Model-1'].parts['Part-1'].faces.getSequenceFromMask(('[#3 ]', 
    ), ))
    
    

#����ABD�նȾ���ͽ����ܶ�

mdb.models['Model-1'].GeneralStiffnessSection(applyThermalStress=0, density=3.18e-10, name='Section-1', poissonDefinition=DEFAULT, referenceTemperature=None, stiffnessMatrix=(7714.0, 6380.0, 7714.0, 0.0, 0.0, 5962.0, 0.0, 0.0, 0.0, 23.6, 0.0, 0.0, 0.0, 19.1, 23.6, 0.0, 0.0, 0.0, 0.0, 0.0, 19.9), useDensity=ON)
mdb.models['Model-1'].parts['Part-1'].SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=Region(faces=mdb.models['Model-1'].parts['Part-1'].faces.getSequenceFromMask(mask=('[#f ]', ), )), sectionName='Section-1', thicknessAssignment=FROM_SECTION)

#����local����ϵ��ָ�ɽ��淽��

mdb.models['Model-1'].parts['Part-1'].DatumCsysByThreePoints(coordSysType=
    CYLINDRICAL, name='Datum csys-2', origin=(0.0, 0.0, 0.0), point1=(0.0, 0.0, 
    1.0), point2=(1.0, 0.0, 0.0))

mdb.models['Model-1'].parts['Part-1'].MaterialOrientation(
    additionalRotationField='', additionalRotationType=ROTATION_NONE, angle=0.0
    , axis=AXIS_3, fieldName='', localCsys=
    mdb.models['Model-1'].parts['Part-1'].datums[11], orientationType=SYSTEM, 
    region=Region(
    faces=mdb.models['Model-1'].parts['Part-1'].faces.getSequenceFromMask(
    mask=('[#f ]', ), )))  

#װ��ʵ��

mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-1-1', part=mdb.models['Model-1'].parts['Part-1'])


#dynamic steps

mdb.models['Model-1'].ExplicitDynamicsStep(improvedDtMethod=ON, 
    linearBulkViscosity=0.06, massScaling=((SEMI_AUTOMATIC, MODEL, 
    THROUGHOUT_STEP, 0.0, 1e-06, BELOW_MIN, 1, 0, 0.0, 0.0, 0, None), ), name=
    'folding', previous='Initial', quadBulkViscosity=1.2)
mdb.models['Model-1'].ExplicitDynamicsStep(improvedDtMethod=ON, 
    linearBulkViscosity=0.06, massScaling=((SEMI_AUTOMATIC, MODEL, 
    THROUGHOUT_STEP, 0.0, 1e-06, BELOW_MIN, 1, 0, 0.0, 0.0, 0, None), ), name=
    'deployment', previous='folding', quadBulkViscosity=1.2)
mdb.models['Model-1'].steps['folding'].setValues(timePeriod=3.0)
mdb.models['Model-1'].steps['deployment'].setValues(timePeriod=3.0)


mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(filter=
    ANTIALIASING, timeInterval=0.01, variables=('CF', 'RF', 'RM', 'RT', 'SE', 
    'SF', 'U', 'UR', 'UT'))
mdb.models['Model-1'].historyOutputRequests['H-Output-1'].setValues(filter=
    ANTIALIASING, timeInterval=0.01, variables=('ALLAE', 'ALLCD', 'ALLCW', 
    'ALLDC', 'ALLDMD', 'ALLFD', 'ALLIE', 'ALLKE', 'ALLMW', 'ALLPD', 'ALLPW', 
    'ALLSE', 'ALLVD', 'ALLWK'))
    
#creat interaction  
 
mdb.models['Model-1'].ContactProperty('IntProp-1')
mdb.models['Model-1'].interactionProperties['IntProp-1'].TangentialBehavior(
    formulation=FRICTIONLESS)
mdb.models['Model-1'].interactionProperties['IntProp-1'].NormalBehavior(
    allowSeparation=ON, constraintEnforcementMethod=DEFAULT, 
    pressureOverclosure=HARD)
mdb.models['Model-1'].ContactExp(createStepName='Initial', name='Int-1')
mdb.models['Model-1'].interactions['Int-1'].includedPairs.setValuesInStep(
    stepName='Initial', useAllstar=ON)
mdb.models['Model-1'].interactions['Int-1'].contactPropertyAssignments.appendInStep(
    assignments=((GLOBAL, SELF, 'IntProp-1'), ), stepName='Initial')
    
#����RP-A,B,C�ο���  

mdb.models['Model-1'].rootAssembly.ReferencePoint(point=(0, 0, 220))
mdb.models['Model-1'].rootAssembly.ReferencePoint(point=(0, 0.0, 0))
mdb.models['Model-1'].rootAssembly.ReferencePoint(point=(0, 0.0, 110))
mdb.models['Model-1'].rootAssembly.features.changeKey(fromName='RP-1', toName='RP-A')
mdb.models['Model-1'].rootAssembly.features.changeKey(fromName='RP-2', toName='RP-B')
mdb.models['Model-1'].rootAssembly.features.changeKey(fromName='RP-3', toName='RP-C')
mdb.models['Model-1'].rootAssembly.Set(name='RP-A', referencePoints=(mdb.models['Model-1'].rootAssembly.referencePoints[4], ))
mdb.models['Model-1'].rootAssembly.Set(name='RP-B', referencePoints=(mdb.models['Model-1'].rootAssembly.referencePoints[5], ))
mdb.models['Model-1'].rootAssembly.Set(name='RP-C', referencePoints=(mdb.models['Model-1'].rootAssembly.referencePoints[6], ))

#creat coupling controling &equation controling

mdb.models['Model-1'].Coupling(controlPoint=Region(referencePoints=(
    mdb.models['Model-1'].rootAssembly.referencePoints[4], )), couplingType=
    KINEMATIC, influenceRadius=WHOLE_SURFACE, localCsys=None, name=
    'Constraint-1', surface=Region(
    side1Edges=mdb.models['Model-1'].rootAssembly.instances['Part-1-1'].edges.getSequenceFromMask(
    mask=('[#20200408 ]', ), )), u1=ON, u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)
mdb.models['Model-1'].Coupling(controlPoint=Region(referencePoints=(
    mdb.models['Model-1'].rootAssembly.referencePoints[5], )), couplingType=
    KINEMATIC, influenceRadius=WHOLE_SURFACE, localCsys=None, name=
    'Constraint-2', surface=Region(
    side1Edges=mdb.models['Model-1'].rootAssembly.instances['Part-1-1'].edges.getSequenceFromMask(
    mask=('[#10800802 ]', ), )), u1=ON, u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)
mdb.models['Model-1'].Equation(name='Constraint-3', terms=((1.0, 'RP-A', 4), (
    -1.0, 'RP-B', 4), (-1.0, 'RP-C', 4)))
    
#ճ��ѹ������ 

mdb.models['Model-1'].Pressure(amplitude=UNSET, createStepName='folding', 
    distributionType=VISCOUS, field='', magnitude=1.4623e-06, name='Load-1', 
    region=Region(
    side1Faces=mdb.models['Model-1'].rootAssembly.instances['Part-1-1'].faces.getSequenceFromMask(
    mask=('[[#f ] ]', ), )))

    
##creat boundcondition

mdb.models['Model-1'].DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name='BC-1', 
    region=mdb.models['Model-1'].rootAssembly.sets['RP-A'], u1=SET, u2=SET, u3=
    SET, ur1=UNSET, ur2=SET, ur3=SET)
mdb.models['Model-1'].DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name='BC-2', 
    region=mdb.models['Model-1'].rootAssembly.sets['RP-B'], u1=SET, u2=SET, u3=
    UNSET, ur1=UNSET, ur2=SET, ur3=SET)
mdb.models['Model-1'].DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name='BC-3', 
    region=mdb.models['Model-1'].rootAssembly.sets['RP-C'], u1=SET, u2=SET, u3=
    SET, ur1=UNSET, ur2=SET, ur3=SET)
    
#����smoothstepamplitude��ֵ����

mdb.models['Model-1'].SmoothStepAmplitude(data=((0.0, 0.0), (3.0, 1.0), (6.0, 0.0)), name='Amp-1', timeSpan=TOTAL)
mdb.models['Model-1'].boundaryConditions['BC-3'].setValuesInStep(amplitude='Amp-1', stepName='folding', ur1=2.996)

#������

mdb.models['Model-1'].parts['Part-1'].seedPart(deviationFactor=0.1, minSizeFactor=0.1, size=3)
mdb.models['Model-1'].parts['Part-1'].setMeshControls(algorithm=ADVANCING_FRONT, elemShape=QUAD, regions=mdb.models['Model-1'].parts['Part-1'].faces.getSequenceFromMask(('[[#f ] ]', ), ))
mdb.models['Model-1'].parts['Part-1'].setElementType(elemTypes=(ElemType(
    elemCode=S4R, elemLibrary=STANDARD, secondOrderAccuracy=ON, hourglassControl=STIFFNESS), ElemType(
    elemCode=S3, elemLibrary=STANDARD)), regions=(
    mdb.models['Model-1'].parts['Part-1'].faces.getSequenceFromMask(('[[#f ] ]', 
    ), ), ))
mdb.models['Model-1'].parts['Part-1'].generateMesh()
mdb.models['Model-1'].rootAssembly.regenerate()

#�ύ����

mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
    description='', echoPrint=OFF, explicitPrecision=DOUBLE_PLUS_PACK, 
    historyPrint=OFF, memory=90, memoryUnits=PERCENTAGE, model='Model-1', 
    modelPrint=OFF, multiprocessingMode=DEFAULT, name='Job-1', 
    nodalOutputPrecision=FULL, numCpus=14, numDomains=14, 
    parallelizationMethodExplicit=DOMAIN, queue=None, resultsFormat=ODB, 
    scratch='', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
mdb.jobs['Job-1'].submit(consistencyChecking=OFF)
mdb.jobs['Job-1'].waitForCompletion()
mdb.saveAs(pathName='Job-1.cae')

##����
#============================================================================================================
#ʧЧָ��
#============================================================================================================
# Faiulre strength parameters
#-----------------------------------------------------------
sF1t = 139.47
sF1c = 63.42
sF3 = 17.73
sF4 = 5.07
sF6 = 1.53

# calculating failure coefficients
#---------------------------------
sJ1 = 1/sF1t - 1/sF1c
sK11 = 1/(sF1t*sF1c)
sK33 = 1/pow(sF3,2)
sK44 = 1/pow(sF4,2)
sK66 = 1/pow(sF6,2)
sK12 = -sK11/2
#------------------------------------------------------------------------------
#---------------------Initialize Global Variables------------------------------
#------------------------------------------------------------------------------	
odb = None
instance = None
odbName = None
allSteps = False# consider all steps or single step
allFrames = False# consider all frames or only final frame
debug = False

#----------------------------------------------------------
# User input: odb data
#----------------------------------------------------------
odbPath = 'Job-1'+'.odb'
stepName = 'folding'
#stepNames = ['folding','deployment']
stepNames = ['folding']
instanceName = 'PART-1-1'


#==========================================================================
# S T A R T
#========================================================================== 
o1 = session.openOdb(name= odbPath, readOnly=0)
odb = session.odbs[odbPath]
odbName = odb.name

assembly = odb.rootAssembly
instance = assembly.instances[instanceName]
  

for sName in stepNames:
	step = odb.steps[sName]
	fCount = 0
	for frame in step.frames:
            global dataFI	
            # containters for element labels and stress-resultants
            labels = []
            dataF = []
            dataM = []
            dataFI = []
            # create reference to append fuctions
            labelsAppend = labels.append
            dataFAppend = dataF.append
            dataMAppend = dataM.append
            dataFIAppend = dataFI.append
            lastLabel = -1
            fieldType = VECTOR

            #take field output SF and SM only from 2-ply sets
            force = frame.fieldOutputs['SF_ANTIALIASING']
            moment = frame.fieldOutputs['SM_ANTIALIASING']
            #twoply = odb.rootAssembly.instances[instanceName].elementSets['ALL_ELEMENTS']
            twoply = odb.rootAssembly.instances[instanceName]
            force_subset_twoply = force.getSubset(region=twoply)
            moment_subset_twoply = moment.getSubset(region=twoply)

            fValues = force_subset_twoply.values#set�е����е�Ԫ
            mValues = moment_subset_twoply.values#set�е����е�Ԫ
            #�����е�Ԫ�н���ѭ��
            for i in range (len(fValues)):

                fValue = fValues[i]
                mValue = mValues[i]
                
                label = fValue.elementLabel
                if lastLabel != label:
                    labelsAppend(label)
                lastLabel = label

                M1, M2, M12 = mValue.data
                N1, N2, N3, N12, N13, N23 = fValue.data
            

            
                Nx = 0.5*(N1 + N2) + N12
                Ny = 0.5*(N1 + N2) - N12
                Nxy = 0.5*(N2 - N1)
                
                Mx = 0.5*(M1 + M2) + M12
                My = 0.5*(M1 + M2) - M12
                Mxy = 0.5*(M2 - M1)

                dataValueM = (Mx, My, Mxy)
                dataValueF = (Nx, Ny, Nxy)

        #-----------------------        
        #       In-plane loads
        #-----------------------
                fIndexIP = sJ1*(Nx+Ny) + sK11*( pow(Nx,2)+ pow(Ny,2) ) + sK12*Nx*Ny + sK33*pow(Nxy,2)
            
        #-----------------------
        #       Moments
        #-----------------------
                if (abs(Mx) >= abs(My)):
                    M = Mx
                else:
                    M = My
                
                fIndexM = sK44*pow(M,2) + sK66*pow(Mxy,2)

        #-----------------------
        #       Interaction
        #-----------------------
                fIndexC = 0
                fIndexCx = 0
                fIndexCy = 0
            
                if (fIndexIP >= 1):
                    fIndexC = 1
                
                else:
                    # Calculating axial strengths 
                    
                    # Calculating sFx
                    sFx = 0.0001            
                    delta = pow((sJ1 + sK12*Ny),2) - 4*sK11*(sJ1*Ny + sK11*pow(Ny,2)+ sK33*pow(Nxy,2)-1)
                    
                    if delta < 0:
                        if debug:
                                print 'Value error, deltaX, b^2-4ac = %s'%delta
                    elif Ny >= 0:
                        sFx = (-(sJ1 + sK12*Ny) + sqrt(delta))/(2*sK11)
                    else:
                        sFx = (-(sJ1 + sK12*Ny) - sqrt(delta))/(2*sK11)        
                    
                    fIndexCx = Nx/sFx + abs(M)/sF4

                    # Calculating sFy
                    sFy = 0.0001
                    delta = pow((sJ1 + sK12*Nx),2) - 4*sK11*(sJ1*Nx + sK11*pow(Nx,2)+ sK33*pow(Nxy,2)-1)
                    
                    if delta < 0:
                        if debug:
                                print 'Value error deltaY, b^2-4ac = %s'%delta
                    elif Nx >= 0:
                        sFy = (-(sJ1 + sK12*Nx) + sqrt(delta))/(2*sK11)
                    else:
                        sFy = (-(sJ1 + sK12*Nx) - sqrt(delta))/(2*sK11)        
                    
                    fIndexCy = Ny/sFy + abs(M)/sF4
                    
                   # selecting maximum index
                
                    if (fIndexCx >= fIndexCy):
                        fIndexC = fIndexCx 
                    else:
                        fIndexC = fIndexCy
                                
                dataValueFI = (fIndexIP, fIndexM, fIndexC)
            
                dataFAppend(dataValueF)
                dataMAppend(dataValueM)
                dataFIAppend(dataValueFI)

            labels = np.array(labels)
            dataF = np.array(dataF)
            dataM = np.array(dataM)
            dataFI = np.array(dataFI)

            if debug:
                print 'len (labels):%s, len(dataF):%s'%(len(labels), len(dataF))
            se = 'FI'
            componentLabels = ['FI_M-1', 'FI_M-2', 'FI_M-3']
            descript = 'Failure Indices'

            fo = frame.FieldOutput(name=se, 
                description=descript, 
                type=fieldType, 
                componentLabels=componentLabels)

            fo.addData(position=INTEGRATION_POINT, 
                instance=instance, 
                labels=labels, 
                data=dataFI) 
            if debug:
                fCount+=1
                print 'Frame No.%s is added'%fCount
odb.save()
session.odbs[odbName].close()

o1 = session.openOdb(name='Job-1.odb', readOnly=False)
session.viewports['Viewport: 1'].setValues(displayedObject=o1)

odb = session.odbs['Job-1.odb']
session.viewports['Viewport: 1'].setValues(displayedObject=odb)
session.viewports['Viewport: 1'].odbDisplay.setFrame(step=0, frame=300)
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(CONTOURS_ON_DEF, ))
#============================================================================================================
#���ʧЧָ��(��Ԫ�ڵ�)
session.fieldReportOptions.setValues(printXYData=OFF, printTotal=OFF)
session.writeFieldReport(fileName='FI.txt', append=ON, sortItem='Node Label', 
    odb=odb, step=0, frame=300, outputPosition=NODAL, variable=(('FI', 
    INTEGRATION_POINT), ), stepFrame=SPECIFY)

session.fieldReportOptions.setValues(printXYData=OFF, printTotal=OFF)
session.writeFieldReport(fileName='FI.txt', append=ON, sortItem='Node Label', 
    odb=odb, step=0, frame=300, outputPosition=INTEGRATION_POINT, variable=(('FI', 
    INTEGRATION_POINT), ), stepFrame=SPECIFY)
#============================================================================================================
#���SK
#============================================================================================================
session.writeFieldReport(fileName='SK.txt', append=ON, sortItem='Node Label', 
    odb=odb, step=0, frame=300, outputPosition=NODAL, variable=((
    'SK_ANTIALIASING', INTEGRATION_POINT), ), stepFrame=SPECIFY)
    #============================================================================================================
#������Ӧ����
#============================================================================================================
xy1 = xyPlot.XYDataFromHistory(odb=odb, 
    outputVariableName='Strain energy: ALLSE for Whole Model', steps=(
    'folding', ), suppressQuery=True, __linkedVpName__='Viewport: 1')
c1 = session.Curve(xyData=xy1)
xyp = session.XYPlot('XYPlot-1')
chartName = xyp.charts.keys()[0]
chart = xyp.charts[chartName]
chart.setValues(curvesToPlot=(c1, ), )
session.charts[chartName].autoColor(lines=True, symbols=True)
session.viewports['Viewport: 1'].setValues(displayedObject=xyp)
session.xyDataObjects.changeKey(fromName='_temp_1', toName='Strian energy')
x0 = session.xyDataObjects['Strian energy']
session.xyReportOptions.setValues(xyData=OFF, minMax=ON)
session.writeXYReport(fileName='Max_strain_energy.txt', xyData=(x0, ))
#============================================================================================================
#������չ������
#============================================================================================================
odbName=session.viewports[session.currentViewportName].odbDisplay.name
session.odbData[odbName].setValues(activeFrames=(('deployment', ('0:-1', )), ))
xyList = xyPlot.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=((
    'RM_ANTIALIASING', NODAL, ((COMPONENT, 'RM1'), )), ), nodeSets=("RP-C", ))
xyp = session.xyPlots['XYPlot-1']
chartName = xyp.charts.keys()[0]
chart = xyp.charts[chartName]
curveList = session.curveSet(xyData=xyList)
chart.setValues(curvesToPlot=curveList)
session.charts[chartName].autoColor(lines=True, symbols=True)
session.xyDataObjects.changeKey(fromName='_RM_ANTIALIASING:RM1 PI: ASSEMBLY N: 3', toName='Moment curve')
x0 = session.xyDataObjects['Moment curve']
session.writeXYReport(fileName='Max_moment.txt', xyData=(x0, ))
#============================================================================================================
session.odbs[odbName].close()
#============================================================================================================
#����
#============================================================================================================
openMdb(pathName='Job-1.cae')
a=mdb.models['Model-1'].rootAssembly
b=a.getArea(a.instances['Part-1-1'].faces)
c=3.18E-10*b*1000
file_handle=open('mass.txt',mode='a+')
print >>file_handle, c
file_handle.close()
#============================================================================================================


