addpath('Current Work Directory ');
%the design variable
Xplot1=45;
Xplot2=57.73;
Xplot3=73.64;
Xplot4=87.27;
Xplot5=46.82;
%reverse normalization treatment；
Xplot11=(Xplot1-45)/(60-45);
Xplot22=(Xplot2-60)/(75-60);
Xplot33=(Xplot3-60.05)/(75-60.05);
Xplot44=(Xplot4-5.033)/(14.967-5.033);
Xplot55=(Xplot5-5)/(14.967-5);
pred11=0.006387+(0.007688-0.006387)*pred([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
pred22=716+(6881.88-716.011)*pred2([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
pred33=345.242+(1248.3-345.242)*pred3([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
pred44=0.225424+(0.681638-0.225424)*pred4([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);