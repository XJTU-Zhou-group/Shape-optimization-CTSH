function f4=pred4(x)
% f=pred(x)
%
% Calculates a Kriging prediction at x
%
% Inputs:
%	x - 1 x k vetor of design variables
%
% Global variables used:
%	ModelInfo.X - n x k matrix of sample locations
%	ModelInfo.y - n x 1 vector of observed data
%   ModelInfo.Theta - 1 x k vector of log(theta)
%   ModelInfo.U - n x n Cholesky factorisation of Psi
%
% Outputs:
%	f - scalar kriging prediction
%
% Copyright 2007 A I J Forrester
%
% This program is free software: you can redistribute it and/or modify  it
% under the terms of the GNU Lesser General Public License as published by
% the Free Software Foundation, either version 3 of the License, or any
% later version.
% 
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
% General Public License for more details.
% 
% You should have received a copy of the GNU General Public License and GNU
% Lesser General Public License along with this program. If not, see
% <http://www.gnu.org/licenses/>.
% Calculate observed data
% extract variables from data structure 
% slower, but makes code easier to follow
global ModelInfo
ModelInfo.X = xlsread('X.xlsx');
ModelInfo.y4 = xlsread('Y4.xlsx');
ModelInfo.Psi4 = xlsread('Psi4.xlsx');
ModelInfo.Theta4 = xlsread('Theta4.xlsx');
ModelInfo.U4 = xlsread('U4.xlsx');
X=ModelInfo.X;
y4=ModelInfo.y4;
theta4=10.^ModelInfo.Theta4;
p=2;  % added p definition (February 10)
U4=ModelInfo.U4;
% calculate number of sample points
n=size(X,1);

% vector of ones
one=ones(n,1);

% calculate mu
mu4=(one'*(U4\(U4'\y4)))/(one'*(U4\(U4'\one)));

% initialise psi to vector of ones
psi4=ones(n,1);

% fill psi vector
for i=1:n
	psi4(i)=exp(-sum(theta4.*abs(X(i,:)-x).^p));
end

% calculate prediction
f4=mu4+psi4'*(U4\(U4'\(y4-one*mu4)));
