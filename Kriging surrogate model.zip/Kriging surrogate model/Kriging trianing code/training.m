 global ModelInfo
% Number of variables
k=5 ;
% Number of sample points
%n = 899;



% Create sampling plan
ModelInfo.X = xlsread('X.xlsx');

% Calculate observed data
ModelInfo.y = xlsread('Y1.xlsx');
ModelInfo.y2 = xlsread('Y2.xlsx');
ModelInfo.y3 = xlsread('Y3.xlsx');
ModelInfo.y4 = xlsread('Y4.xlsx');

% Set upper and lower bounds for search of log theta
UpperTheta =ones(1,k).*2;
LowerTheta =ones(1,k).*-3;

%options=optimoptions('ga','Generations',2000);
%options.Generations=2000;
% Run GA search of likelihood
 [ModelInfo.Theta,MinNegLnLikelihood] =...
ga(@likelihood,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike,ModelInfo.Psi,ModelInfo.U] = likelihood(ModelInfo.Theta);

% Run GA search of likelihood
[ModelInfo.Theta2,MinNegLnLikelihood2] =...
ga(@likelihood2,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike2,ModelInfo.Psi2,ModelInfo.U2] = likelihood2(ModelInfo.Theta2);

% Run GA search of likelihood
[ModelInfo.Theta3,MinNegLnLikelihood3] =...
ga(@likelihood3,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike3,ModelInfo.Psi3,ModelInfo.U3] = likelihood3(ModelInfo.Theta3);

% Run GA search of likelihood
[ModelInfo.Theta4,MinNegLnLikelihood4] =...
ga(@likelihood4,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike4,ModelInfo.Psi4,ModelInfo.U4] = likelihood4(ModelInfo.Theta4);

xlswrite('U.xlsx',U);
xlswrite('U2.xlsx',U2);
xlswrite('U3.xlsx',U3);
xlswrite('U4.xlsx',U4);
xlswrite('Psi.xlsx',Psi);
xlswrite('Psi2.xlsx',Psi2);
xlswrite('Psi3.xlsx',Psi3);
xlswrite('Psi4.xlsx',Psi4);
xlswrite('Theta.xlsx',Theta); 
xlswrite('Theta2.xlsx',Theta2);
xlswrite('Theta3.xlsx',Theta3);
xlswrite('Theta4.xlsx',Theta4);
