function [NegLnLike4,Psi4,U4]=likelihood4(x)
% [NegLnLike,Psi,U]=likelihood(x)
%
% Calculates the negative of the concentrated ln-likelihood
%
% Inputs:
%	x - vector of log(theta) parameters
%
% Global variables used:
%	ModelInfo.X - n x k matrix of sample locations
%	ModelInfo.y - n x 1 vector of observed data
%
% Outputs:
%	NegLnLike - concentrated log-likelihood *-1 for minimising
%	Psi - correlation matrix
%	U - Choleski factorisation of correlation matrix
%
% Copyright 2007 A I J Forrester
%
% This program is free software: you can redistribute it and/or modify  it
% under the terms of the GNU Lesser General Public License as published by
% the Free Software Foundation, either version 3 of the License, or any
% later version.
% 
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
% General Public License for more details.
% 
% You should have received a copy of the GNU General Public License and GNU
% Lesser General Public License along with this program. If not, see
% <http://www.gnu.org/licenses/>.

global ModelInfo
X=ModelInfo.X;
y4=ModelInfo.y4;
theta4=10.^x;
p=2;  % added p definition (February 10)
n=size(X,1);
one=ones(n,1);

% Pre-allocate memory
Psi4=zeros(n,n);
% Build upper half of correlation matrix
for i=1:n
	for j=i+1:n
		Psi4(i,j)=exp(-sum(theta4.*abs(X(i,:)-X(j,:)).^p)); % abs added (February 10)
	end
end

% Add upper and lower halves and diagonal of ones plus 
% small number to reduce ill-conditioning
Psi4=Psi4+Psi4'+eye(n)+eye(n).*eps; 

% Cholesky factorisation
[U4,p]=chol(Psi4);

% Use penalty if ill-conditioned
if p>0
    NegLnLike4=1e4;
else
    
    % Sum lns of diagonal to  find ln(abs(det(Psi)))
    LnDetPsi4=2*sum(log(abs(diag(U4))));

    % Use back-substitution of Cholesky instead of inverse
    mu4=(one'*(U4\(U4'\y4)))/(one'*(U4\(U4'\one)));
    SigmaSqr4=((y4-one*mu4)'*(U4\(U4'\(y4-one*mu4))))/n;
    NegLnLike4=-1*(-(n/2)*log(SigmaSqr4) - 0.5*LnDetPsi4);
end
%xlswrite('E:\代理模型\5个变量Kriging surrogate\5个变量4个输出_铰链\U4.xlsx',U4);
%xlswrite('E:\代理模型\5个变量Kriging surrogate\5个变量4个输出_铰链\Psi4.xlsx',Psi4);