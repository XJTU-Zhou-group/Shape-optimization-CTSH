function f5=pred5(x)
% f=pred(x)
%
% Calculates a Kriging prediction at x
%
% Inputs:
%	x - 1 x k vetor of design variables
%
% Global variables used:
%	ModelInfo.X - n x k matrix of sample locations
%	ModelInfo.y - n x 1 vector of observed data
%   ModelInfo.Theta - 1 x k vector of log(theta)
%   ModelInfo.U - n x n Cholesky factorisation of Psi
%
% Outputs:
%	f - scalar kriging prediction
%
% Copyright 2007 A I J Forrester
%
% This program is free software: you can redistribute it and/or modify  it
% under the terms of the GNU Lesser General Public License as published by
% the Free Software Foundation, either version 3 of the License, or any
% later version.
% 
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
% General Public License for more details.
% 
% You should have received a copy of the GNU General Public License and GNU
% Lesser General Public License along with this program. If not, see
% <http://www.gnu.org/licenses/>.
% Calculate observed data
% extract variables from data structure 
% slower, but makes code easier to follow
global ModelInfo
ModelInfo.X = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\X.xlsx');
ModelInfo.y5 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y5.xlsx');
ModelInfo.Psi5 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi5.xlsx');
ModelInfo.Theta5 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta5.xlsx');
ModelInfo.U5 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U5.xlsx');
X=ModelInfo.X;
y5=ModelInfo.y5;
theta5=10.^ModelInfo.Theta5;
p=2;  % added p definition (February 10)
U5=ModelInfo.U5;
% calculate number of sample points
n=size(X,1);

% vector of ones
one=ones(n,1);

% calculate mu
mu5=(one'*(U5\(U5'\y5)))/(one'*(U5\(U5'\one)));

% initialise psi to vector of ones
psi5=ones(n,1);

% fill psi vector
for i=1:n
	psi5(i)=exp(-sum(theta5.*abs(X(i,:)-x).^p));
end

% calculate prediction
f5=mu5+psi5'*(U5\(U5'\(y5-one*mu5)));
