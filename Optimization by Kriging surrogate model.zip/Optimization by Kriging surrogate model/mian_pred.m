% Number of variables
%global ModelInfo
k=5 ;
% Number of sample points
%n = 899;
% Create sampling plan
%预测值计算
addpath('E:\2022_4_AIAAJ\Kriging Surrogate model\5个变量Kriging surrogate\AIAA');
load('matlab.mat')
% load('PSX2.mat');
% load('PSX3.mat');
% load('PSX4.mat');
% load('PSY2.mat');
% load('PSY3.mat');
% load('PSy.mat');
% load('PSy2.mat');
% load('PSy3.mat');
% load('PSy4.mat');
% load('PSy5.mat');
% load('PSy6.mat');
X2=50.669;
x2= mapminmax('apply',X2,PSX2);
X3=60.552;
x3= mapminmax('apply',X3,PSX3);
X4=69.331;
x4= mapminmax('apply',X4,PSX4);
Y2=13.127;
y2= mapminmax('apply',Y2,PSY2);
Y3=10.518;
y3= mapminmax('apply',Y3,PSY3);
% 
% %A2= mapminmax('reverse',A1,PS)
Energy=mapminmax('reverse',pred([x2 x3 x4 y2 y3]),PSy);
Mass=mapminmax('reverse',pred2([x2 x3 x4 y2 y3]),PSy2);
Moment=mapminmax('reverse',pred3([x2 x3 x4 y2 y3]),PSy3);
FI1=mapminmax('reverse',pred4([x2 x3 x4 y2 y3]),PSy4);
FI2=mapminmax('reverse',pred5([x2 x3 x4 y2 y3]),PSy5);
FI3=mapminmax('reverse',pred6([x2 x3 x4 y2 y3]),PSy6);
% Xplot1=50.669;
% Xplot2=60.552;
% Xplot3=69.331;
% Xplot4=13.127;
% Xplot5=10.518;
% Xplot11=(Xplot1-45)/(60-45);
% Xplot22=(Xplot2-60)/(75-60);
% Xplot33=(Xplot3-60)/(75-60);
% Xplot44=(Xplot4-5)/(15-5);
% Xplot55=(Xplot5-5)/(15-5);
% pred11=451.066+(751.954-451.066)*pred([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
% pred22=0.0065+(0.0077-0.0065)*pred2([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
% pred33=1650+(6778.5-1650)*pred3([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
% pred44=0.098+(1.5265-0.098)*pred4([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
% pred55=0.414+(7.5912-0.414)*pred5([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);
% pred66=0.7123+(2.9217-0.7123)*pred6([Xplot11 Xplot22 Xplot33 Xplot44 Xplot55]);