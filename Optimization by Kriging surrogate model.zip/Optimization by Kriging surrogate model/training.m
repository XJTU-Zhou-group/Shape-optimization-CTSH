clc;
clear all;
global ModelInfo
% Number of variables
k=5 ;
% Number of sample points
%n = 899;

% Create sampling plan
ModelInfo.X = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\X.xlsx');

% Calculate observed data
ModelInfo.y = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y1.xlsx');

ModelInfo.y2 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y2.xlsx');

ModelInfo.y3 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y3.xlsx');

ModelInfo.y4 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y4.xlsx');

ModelInfo.y5 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y5.xlsx');

ModelInfo.y6 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y6.xlsx');

% Set upper and lower bounds for search of log theta
UpperTheta =ones(1,k).*2;
LowerTheta =ones(1,k).*-3;

%options=optimoptions('ga','Generations',2000);
%options.Generations=2000;
% Run GA search of likelihood
 [ModelInfo.Theta,MinNegLnLikelihood] =...
ga(@likelihood,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike,ModelInfo.Psi,ModelInfo.U] = likelihood(ModelInfo.Theta);

% Run GA search of likelihood
[ModelInfo.Theta2,MinNegLnLikelihood2] =...
ga(@likelihood2,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike2,ModelInfo.Psi2,ModelInfo.U2] = likelihood2(ModelInfo.Theta2);

% Run GA search of likelihood
[ModelInfo.Theta3,MinNegLnLikelihood3] =...
ga(@likelihood3,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike3,ModelInfo.Psi3,ModelInfo.U3] = likelihood3(ModelInfo.Theta3);

% Run GA search of likelihood
[ModelInfo.Theta4,MinNegLnLikelihood4] =...
ga(@likelihood4,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike4,ModelInfo.Psi4,ModelInfo.U4] = likelihood4(ModelInfo.Theta4);

% Run GA search of likelihood
[ModelInfo.Theta5,MinNegLnLikelihood5] =...
ga(@likelihood5,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike5,ModelInfo.Psi5,ModelInfo.U5] = likelihood4(ModelInfo.Theta5);

% Run GA search of likelihood
[ModelInfo.Theta6,MinNegLnLikelihood6] =...
ga(@likelihood6,k,[],[],[],[], LowerTheta,UpperTheta);

% Put Cholesky factorization of Psi, into ModelInfo
[NegLnLike6,ModelInfo.Psi6,ModelInfo.U6] = likelihood4(ModelInfo.Theta6);

xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U.xlsx',ModelInfo.U);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U2.xlsx',ModelInfo.U2);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U3.xlsx',ModelInfo.U3);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U4.xlsx',ModelInfo.U4);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U5.xlsx',ModelInfo.U5);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U6.xlsx',ModelInfo.U6);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi.xlsx',ModelInfo.Psi);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi2.xlsx',ModelInfo.Psi2);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi3.xlsx',ModelInfo.Psi3);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi4.xlsx',ModelInfo.Psi4);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi5.xlsx',ModelInfo.Psi5);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi6.xlsx',ModelInfo.Psi6);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta.xlsx',ModelInfo.Theta); 
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta2.xlsx',ModelInfo.Theta2);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta3.xlsx',ModelInfo.Theta3);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta4.xlsx',ModelInfo.Theta4);
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta5.xlsx',ModelInfo.Theta5); 
xlswrite('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta6.xlsx',ModelInfo.Theta6);