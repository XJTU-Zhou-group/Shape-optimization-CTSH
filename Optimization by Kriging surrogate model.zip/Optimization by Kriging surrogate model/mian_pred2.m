% Number of variables
%global ModelInfo
k=5 ;
% Number of sample points
%n = 899;
% Create sampling plan
%预测值计算
addpath('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2');
X2=54.621;
X3=70.311;
X4=64.178;
Y2=6.5605;
Y3=5.00;
Energy=pred([X2 X3 X4 Y2 Y3]);
Mass=pred2([X2 X3 X4 Y2 Y3]);
Moment=pred3([X2 X3 X4 Y2 Y3]);
FI1=pred4([X2 X3 X4 Y2 Y3]);
FI2=pred5([X2 X3 X4 Y2 Y3]);
FI3=pred6([X2 X3 X4 Y2 Y3]);