function f3=pred3(x)
% f=pred(x)
%
% Calculates a Kriging prediction at x
%
% Inputs:
%	x - 1 x k vetor of design variables
%
% Global variables used:
%	ModelInfo.X - n x k matrix of sample locations
%	ModelInfo.y - n x 1 vector of observed data
%   ModelInfo.Theta - 1 x k vector of log(theta)
%   ModelInfo.U - n x n Cholesky factorisation of Psi
%
% Outputs:
%	f - scalar kriging prediction
%
% Copyright 2007 A I J Forrester
%
% This program is free software: you can redistribute it and/or modify  it
% under the terms of the GNU Lesser General Public License as published by
% the Free Software Foundation, either version 3 of the License, or any
% later version.
% 
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
% General Public License for more details.
% 
% You should have received a copy of the GNU General Public License and GNU
% Lesser General Public License along with this program. If not, see
% <http://www.gnu.org/licenses/>.
global ModelInfo
ModelInfo.X = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\X.xlsx');
ModelInfo.y3 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Y3.xlsx');
ModelInfo.Psi3 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Psi3.xlsx');
ModelInfo.Theta3 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\Theta3.xlsx');
ModelInfo.U3 = xlsread('E:\2022_4_AIAAJ\Kriging Surrogate model\Kriging surrogate model matlab\AIAA\2\U3.xlsx');
global ModelInfo
% Calculate observed data
% extract variables from data structure 
% slower, but makes code easier to follow
X=ModelInfo.X;
y3=ModelInfo.y3;
theta3=10.^ModelInfo.Theta3;
p=2;  % added p definition (February 10)
U3=ModelInfo.U3;
% calculate number of sample points
n=size(X,1);

% vector of ones
one=ones(n,1);

% calculate mu
mu3=(one'*(U3\(U3'\y3)))/(one'*(U3\(U3'\one)));

% initialise psi to vector of ones
psi3=ones(n,1);

% fill psi vector
for i=1:n
	psi3(i)=exp(-sum(theta3.*abs(X(i,:)-x).^p));
end

% calculate prediction
f3=mu3+psi3'*(U3\(U3'\(y3-one*mu3)));
